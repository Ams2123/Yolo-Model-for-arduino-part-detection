# Arduino Mega Board > 2025-02-24 1:11am
https://universe.roboflow.com/pest-detection-aabl8/arduino-mega-board

Provided by a Roboflow user
License: CC BY 4.0

